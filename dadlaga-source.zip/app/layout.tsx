import './globals.css';
import type { ReactNode } from 'react';
export const metadata={ title:'Дадлага — Өнөөдрийн туршлага, маргаашийн ур чадвар', description:'ҮУПК-ийн дадлагын цахим дэвтэр. Тэмдэглэлээ хөтөлж, ахицаа харж, ур чадвараа бүтээ.', icons:{icon:'/assets/production-logo.png'} };
export default function RootLayout({children}:{children:ReactNode}) {return <html lang="mn"><body>{children}</body></html>;}
