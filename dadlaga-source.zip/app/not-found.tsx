import Link from 'next/link';
export default function NotFound(){return <main className="app-loading"><span className="eyebrow">404 / ХУУДАС ОЛДСОНГҮЙ</span><h1>Эндээс шинэ зам сонгоё.</h1><Link href="/" className="btn btn-red">Нүүр хуудас руу ↗</Link></main>;}
