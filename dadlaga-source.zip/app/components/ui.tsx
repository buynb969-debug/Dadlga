'use client';
import { ArrowUpRight, Check, Clock3, Loader2, AlertCircle, X } from 'lucide-react';
import type { ReactNode } from 'react';
import { useEffect, useRef } from 'react';
import { statusNames } from '../../lib/content';
export const IconArrow=()=> <ArrowUpRight size={18} strokeWidth={1.8}/>;
export function Badge({status}:{status:string}) {return <span className={`badge badge-${status}`}><i/>{statusNames[status]||status}</span>;}
export function SaveState({status,error,onRetry}:{status:string;error?:string;onRetry:()=>void}) {return <button className={`save-state ${status}`} onClick={onRetry} title={error||'Одоо хадгалах'}>{status==='saving'?<Loader2 size={14} className="spin"/>:status==='error'?<AlertCircle size={14}/>:status==='waiting'?<Clock3 size={14}/>:<Check size={14}/>}<span>{status==='saving'?'Хадгалж байна':status==='error'?'Хадгалагдсангүй · Дахин оролдох':status==='waiting'?'Өөрчлөлт хадгалагдаж байна':'Бүх өөрчлөлт хадгалагдсан'}</span></button>;}
export function Empty({icon,title,children,action}:{icon?:ReactNode;title:string;children?:ReactNode;action?:ReactNode}) {return <div className="empty"><div className="empty-icon">{icon}</div><h3>{title}</h3><p>{children}</p>{action}</div>;}
export function Modal({title,children,onClose,wide=false}:{title:string;children:ReactNode;onClose:()=>void;wide?:boolean}) {
  const element=useRef<HTMLElement>(null),close=useRef(onClose);close.current=onClose;
  useEffect(()=>{
    const previous=document.activeElement as HTMLElement|null,overflow=document.body.style.overflow;
    document.body.style.overflow='hidden';element.current?.querySelector<HTMLElement>('button,input,textarea,select,a[href]')?.focus();
    const key=(event:KeyboardEvent)=>{
      if(event.key==='Escape'){event.preventDefault();close.current();}
      if(event.key==='Tab'){
        const all=Array.from(element.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled):not([hidden]),textarea:not(:disabled),select:not(:disabled),a[href]')||[]).filter(e=>e.offsetParent!==null);
        if(!all.length)return;const first=all[0],last=all[all.length-1];
        if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
      }
    };
    document.addEventListener('keydown',key);return()=>{document.removeEventListener('keydown',key);document.body.style.overflow=overflow;previous?.focus();};
  },[]);
  return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}><section ref={element} className={`modal ${wide?'modal-wide':''}`} role="dialog" aria-modal="true" aria-label={title}><div className="modal-heading"><h2>{title}</h2><button className="icon-btn" aria-label="Хаах" onClick={onClose}><X size={20}/></button></div>{children}</section></div>;
}
