import { createInterface } from 'node:readline';
import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';

console.log('Ready for Site credential JSON on hidden stdin.');
const input=createInterface({input:process.stdin,terminal:false});
for await(const line of input){
  const credential=JSON.parse(line);
  const gitEnv={...process.env,GIT_TERMINAL_PROMPT:'0'};
  if(credential.auth_mode!=='work_proxy'){
    gitEnv.GIT_CONFIG_COUNT='1';gitEnv.GIT_CONFIG_KEY_0=`http.${new URL(credential.remote_url).origin}/.extraheader`;
    gitEnv.GIT_CONFIG_VALUE_0=`Authorization: Bearer ${credential.token}`;
  }
  const git=(args,{allowFailure=false,quiet=false}={})=>{
    const result=spawnSync('git',args,{env:gitEnv,encoding:'utf8'});
    if(result.status!==0&&!allowFailure){console.error(`Git ${args[0]} failed: ${result.stderr.replaceAll(credential.token||'\0','[redacted]')}`);process.exit(1);}
    if(!quiet&&result.stdout)process.stdout.write(result.stdout);
    return result;
  };
  const remote=git(['ls-remote','--heads',credential.remote_url],{quiet:true});
  if(!existsSync('.git')){
    git(['init','-b',credential.branch]);git(['config','user.name','Codex']);git(['config','user.email','codex@openai.com']);
  }
  const origin=git(['remote','get-url','origin'],{allowFailure:true,quiet:true});
  if(origin.status!==0)git(['remote','add','origin',credential.remote_url]);
  else if(origin.stdout.trim()!==credential.remote_url){console.error('Existing Git origin belongs to another repository.');process.exit(1);}
  if(remote.stdout.trim()&&!git(['rev-parse','--verify','HEAD'],{allowFailure:true,quiet:true}).stdout.trim()){
    console.error('Remote source contains an existing branch; inspect before initializing.');process.exit(1);
  }
  git(['add','.']);
  const changed=git(['diff','--cached','--quiet'],{allowFailure:true,quiet:true});
  if(changed.status!==0)git(['commit','-m','Build Mongolian internship notebook portal']);
  git(['push','origin',`HEAD:${credential.branch}`]);
  const sha=git(['rev-parse','HEAD'],{quiet:true}).stdout.trim();
  console.log(JSON.stringify({commit_sha:sha}));
  input.close();process.stdin.destroy();break;
}
