import { hashPassword } from 'better-auth/crypto';
import { randomBytes } from 'node:crypto';
import { createInterface } from 'node:readline';
console.log('Ready for password on hidden stdin.');
const input=createInterface({input:process.stdin,terminal:false});
for await(const password of input){
  const result={adminHash:await hashPassword(password),authSecret:randomBytes(32).toString('hex')};
  process.stdout.write(JSON.stringify(result)+'\n');input.close();process.stdin.destroy();break;
}
