import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
process.env.WRANGLER_LOG_PATH = resolve('.wrangler/logs');
process.env.WRANGLER_SEND_METRICS = 'false';
process.env.CLOUDFLARE_CF_FETCH_ENABLED = 'false';
mkdirSync(process.env.WRANGLER_LOG_PATH,{recursive:true});
