import { sqliteTable, text, integer, real } from 'drizzle-orm/sqlite-core';

export const user = sqliteTable('user', {
  id: text('id').primaryKey(), name: text('name').notNull(), email: text('email').notNull().unique(),
  emailVerified: integer('email_verified', { mode: 'boolean' }).notNull().default(false), image: text('image'),
  role: text('role').notNull().default('intern'), status: text('status').notNull().default('pending'),
  createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull(), updatedAt: integer('updated_at', { mode: 'timestamp_ms' }).notNull(),
});
export const session = sqliteTable('session', {
  id: text('id').primaryKey(), token: text('token').notNull().unique(),
  expiresAt: integer('expires_at', { mode: 'timestamp_ms' }).notNull(),
  createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull(), updatedAt: integer('updated_at', { mode: 'timestamp_ms' }).notNull(),
  ipAddress: text('ip_address'), userAgent: text('user_agent'), userId: text('user_id').notNull().references(() => user.id, { onDelete: 'cascade' }),
});
export const account = sqliteTable('account', {
  id: text('id').primaryKey(), accountId: text('account_id').notNull(), providerId: text('provider_id').notNull(),
  userId: text('user_id').notNull().references(() => user.id, { onDelete: 'cascade' }), password: text('password'),
  accessToken: text('access_token'), refreshToken: text('refresh_token'), idToken: text('id_token'), scope: text('scope'),
  accessTokenExpiresAt: integer('access_token_expires_at', { mode: 'timestamp_ms' }), refreshTokenExpiresAt: integer('refresh_token_expires_at', { mode: 'timestamp_ms' }),
  createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull(), updatedAt: integer('updated_at', { mode: 'timestamp_ms' }).notNull(),
});
export const verification = sqliteTable('verification', {
  id: text('id').primaryKey(), identifier: text('identifier').notNull(), value: text('value').notNull(),
  expiresAt: integer('expires_at', { mode: 'timestamp_ms' }).notNull(),
  createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull(), updatedAt: integer('updated_at', { mode: 'timestamp_ms' }).notNull(),
});
export const rateLimit = sqliteTable('rate_limit', {
  id: text('id').primaryKey(), key: text('key').notNull().unique(), count: integer('count').notNull(), lastRequest: integer('last_request').notNull(),
});
export const notebooks = sqliteTable('notebooks', {
  id: text('id').primaryKey(), userId: text('user_id').notNull().unique().references(() => user.id),
  profile: text('profile').notNull().default('{}'), sections: text('sections').notNull().default('{}'), schedule: text('schedule').notNull().default('[]'),
  safetyAcknowledgedAt: text('safety_acknowledged_at'), status: text('status').notNull().default('draft'),
  comment: text('comment').notNull().default(''), evaluation: text('evaluation').notNull().default('{}'),
  revision: integer('revision').notNull().default(0), createdAt: text('created_at').notNull(), updatedAt: text('updated_at').notNull(),
});
export const entries = sqliteTable('entries', {
  id: text('id').primaryKey(), notebookId: text('notebook_id').notNull().references(() => notebooks.id),
  date: text('date').notNull(), work: text('work').notNull().default(''), hours: real('hours').notNull().default(0), competency: text('competency').notNull().default(''),
  status: text('status').notNull().default('draft'), comment: text('comment').notNull().default(''),
  competent: integer('competent', { mode: 'boolean' }), revision: integer('revision').notNull().default(0),
  createdAt: text('created_at').notNull(), updatedAt: text('updated_at').notNull(),
});
export const attachments = sqliteTable('attachments', {
  id: text('id').primaryKey(), entryId: text('entry_id').notNull().references(() => entries.id),
  userId: text('user_id').notNull().references(() => user.id), key: text('key').notNull().unique(),
  name: text('name').notNull(), type: text('type').notNull(), size: integer('size').notNull(), createdAt: text('created_at').notNull(),
});
