import { Miniflare, Log, LogLevel, convertV4MiniflareOptions } from 'miniflare';
import { hashPassword } from 'better-auth/crypto';
import { readFileSync, readdirSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';
import { PDFDocument } from 'pdf-lib';

const origin='http://dadlaga.test';
const mf=new Miniflare(convertV4MiniflareOptions({
  workers:[{name:'app',
  modules:[{type:'ESModule',path:resolve('dist/server/index.js')},...readdirSync('dist/server',{recursive:true}).filter(f=>f.endsWith('.js')&&f!=='index.js').map(f=>({type:'ESModule',path:resolve('dist/server',f)}))],modulesRoot:resolve('dist/server'),
  compatibilityDate:'2026-11-01',compatibilityFlags:['nodejs_compat'],
  d1Databases:['DB'],r2Buckets:['BUCKET'],assets:{directory:resolve('dist/client'),binding:'ASSETS',run_worker_first:true,routerConfig:{has_user_worker:true}},
  bindings:{AUTH_SECRET:'integration-test-secret-at-least-thirty-two-characters',ADMIN_EMAIL:'admin@dadlaga.test',ADMIN_PASSWORD_HASH:await hashPassword('TestAdmin!2026'),SITE_URL:origin},
  }],cf:false,
  log:new Log(LogLevel.WARN),
}));
let assertions=0;const check=(ok,message)=>{assert.ok(ok,message);assertions++;};
const cookieJars=new Map();
async function request(client,path,method='GET',value,expected=200,extra={}){
  const headers={origin,'cf-connecting-ip':client==='admin'?'192.0.2.1':client==='a'?'192.0.2.2':'192.0.2.3',...(cookieJars.get(client)?{cookie:cookieJars.get(client)}:{}),...extra};
  let body;
  if(value instanceof FormData){const encoded=new Request(origin,{method:'POST',body:value});headers['content-type']=encoded.headers.get('content-type');body=new Uint8Array(await encoded.arrayBuffer());}else if(value!==undefined){headers['content-type']='application/json';body=JSON.stringify(value);}
  const response=await mf.dispatchFetch(origin+path,{method,headers,body});
  const cookies=response.headers.getSetCookie();if(cookies.length)cookieJars.set(client,cookies.map(c=>c.split(';')[0]).join('; '));
  if(response.status!==expected){const text=await response.text();throw new Error(`${method} ${path}: expected ${expected}, received ${response.status}: ${text.slice(0,650)}`);}
  assertions++;
  if(response.headers.get('content-type')?.includes('application/json'))return response.json();
  return response;
}
try{
  const db=await mf.getD1Database('DB');
  for(const filename of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort()){
    const sql=readFileSync(`drizzle/${filename}`,'utf8');
    for(const statement of sql.split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean))await db.prepare(statement).run();
  }
  const home=await request('anon','/');check((await home.text()).includes('Өнөөдрийн'),'Home SSR contains Mongolian hero');
  for(const path of ['/about','/login','/register','/app','/admin','/assets/production-logo.png','/assets/nomin-logo.svg','/assets/dadlagyn-devter.pdf'])await request('anon',path);
  await request('anon','/api/me','GET',undefined,401);
  await request('a','/api/auth/sign-up/email','POST',{name:'Өлзий',email:'a@dadlaga.test',password:'TraineeTest!2026',role:'admin',status:'active'});
  await request('a','/api/auth/sign-in/email','POST',{email:'a@dadlaga.test',password:'TraineeTest!2026'},403);
  await request('admin','/api/auth/sign-in/email','POST',{email:'admin@dadlaga.test',password:'TestAdmin!2026'});
  const userList=await request('admin','/api/admin/users');const a=userList.users.find(u=>u.email==='a@dadlaga.test');
  check(a.role==='intern'&&a.status==='pending','Signup cannot inject admin role or active status');
  await request('admin',`/api/admin/users/${a.id}`,'PATCH',{status:'active'});
  await request('a','/api/auth/sign-in/email','POST',{email:'a@dadlaga.test',password:'TraineeTest!2026'});
  await request('a','/api/admin/users','GET',undefined,403);
  let {notebook:book}=await request('a','/api/notebooks/mine');const bookId=book.id;
  check(book.schedule.length===27,'Initial schedule has 27 weeks');check(book.profile.organization==='Номин','Initial organization is Nomin');
  check((await request('a','/api/notebooks/mine')).notebook.id===bookId,'Notebook creation is idempotent');
  const profile={...book.profile,lastName:'Бат',firstName:'Өлзий',birthDate:'2005-04-08',startDate:'2026-09-01',endDate:'2026-12-30',phone:'99112233'};
  const sections={organizationIntro:'Номин байгууллагын танилцуулга.',innovation:'Шинэ технологи — өгөгдлийн сан.',selfAssessment:'Өөрийн үнэлгээ, дүгнэлт.',report:'Дадлагын тайлан. Өөрийн сурсан ур чадвар. '.repeat(55),certificate:'Ажлаа хариуцлагатай гүйцэтгэсэн.'};
  const stale=book.revision;
  ({notebook:book}=await request('a',`/api/notebooks/${bookId}`,'PATCH',{profile,sections,schedule:book.schedule,revision:book.revision}));
  await request('a',`/api/notebooks/${bookId}`,'PATCH',{profile,sections,schedule:book.schedule,revision:stale},409);
  await request('a',`/api/notebooks/${bookId}`,'PATCH',{profile,sections,schedule:book.schedule,revision:book.revision},403,{origin:'https://other.test'});
  ({notebook:book}=await request('a',`/api/notebooks/${bookId}/safety`,'POST',{}));
  let {entry}=await request('a',`/api/notebooks/${bookId}/entries`,'POST',{},201);
  check(/^\d{4}-\d{2}-\d{2}$/.test(entry.date),'Initial entry date uses ISO format');
  await request('a',`/api/entries/${entry.id}/submit`,'POST',{},400);
  ({entry}=await request('a',`/api/entries/${entry.id}`,'PATCH',{date:'2026-11-13',work:'Сүлжээний төхөөрөмжийг тохируулж, өгөгдөл хамгаалах арга судлав. '.repeat(20)+'Уртүг'.repeat(100),hours:8,competency:'security',revision:entry.revision}));
  const invalid=new FormData();invalid.set('file',new File(['not an image'],'fake.png',{type:'image/png'}));
  await request('a',`/api/entries/${entry.id}/files`,'POST',invalid,400);
  const form=new FormData();form.set('file',new File([readFileSync('public/assets/production-logo.png')],'Ажлын зураг.png',{type:'image/png'}));
  const {file}=await request('a',`/api/entries/${entry.id}/files`,'POST',form,201);
  const image=await request('a',`/api/files/${file.id}`);check(image.headers.get('content-type')==='image/png','Private attachment streams correct type');
  await request('b','/api/auth/sign-up/email','POST',{name:'Хоёр дахь суралцагч',email:'b@dadlaga.test',password:'SecondTrainee!2026'});
  const b=(await request('admin','/api/admin/users')).users.find(u=>u.email==='b@dadlaga.test');await request('admin',`/api/admin/users/${b.id}`,'PATCH',{status:'active'});
  await request('b','/api/auth/sign-in/email','POST',{email:'b@dadlaga.test',password:'SecondTrainee!2026'});
  await request('b',`/api/notebooks/${bookId}`,'GET',undefined,404);
  await request('b',`/api/files/${file.id}`,'GET',undefined,404);
  await request('b',`/api/entries/${entry.id}`,'PATCH',{date:'2026-11-13',work:'Access denied',hours:2,competency:'web',revision:entry.revision},404);
  const bBook=(await request('b','/api/notebooks/mine')).notebook;
  const bEntry=(await request('b',`/api/notebooks/${bBook.id}/entries`,'POST',{},201)).entry;
  const firstUpload=new FormData();firstUpload.set('file',new File([readFileSync('public/assets/production-logo.png')],'photo.png',{type:'image/png'}));
  const firstFile=(await request('b',`/api/entries/${bEntry.id}/files`,'POST',firstUpload,201)).file;
  await request('b',`/api/files/${firstFile.id}`,'DELETE');
  await request('b',`/api/files/${firstFile.id}`,'GET',undefined,404);
  const secondUpload=new FormData();secondUpload.set('file',new File([readFileSync('public/assets/production-logo.png')],'photo.png',{type:'image/png'}));
  const secondFile=(await request('b',`/api/entries/${bEntry.id}/files`,'POST',secondUpload,201)).file;
  await request('b',`/api/entries/${bEntry.id}`,'DELETE');
  await request('b',`/api/files/${secondFile.id}`,'GET',undefined,404);
  check((await request('b','/api/notebooks/mine')).entries.length===0,'Deleting draft also deletes its attachment metadata');
  await request('b','/api/auth/change-password','POST',{currentPassword:'SecondTrainee!2026',newPassword:'UpdatedTrainee!2026',revokeOtherSessions:true});
  await request('b','/api/auth/sign-out','POST',{});
  await request('b','/api/auth/sign-in/email','POST',{email:'b@dadlaga.test',password:'SecondTrainee!2026'},401);
  await request('b','/api/auth/sign-in/email','POST',{email:'b@dadlaga.test',password:'UpdatedTrainee!2026'});
  await request('a',`/api/entries/${entry.id}/submit`,'POST',{});
  await request('a',`/api/entries/${entry.id}`,'PATCH',{date:'2026-11-13',work:'Locked',hours:2,competency:'web',revision:entry.revision},409);
  await request('admin',`/api/entries/${entry.id}/review`,'POST',{status:'returned',comment:''},400);
  await request('admin',`/api/entries/${entry.id}/review`,'POST',{status:'returned',comment:'Хийсэн ажлын үр дүнгээ нэмээрэй.'});
  entry=(await request('a',`/api/notebooks/${bookId}`)).entries[0];
  ({entry}=await request('a',`/api/entries/${entry.id}`,'PATCH',{date:entry.date,work:entry.work+' Үр дүн: сүлжээ тогтвортой ажиллав.',hours:8,competency:'security',revision:entry.revision}));
  await request('a',`/api/entries/${entry.id}/submit`,'POST',{});
  await request('admin',`/api/entries/${entry.id}/review`,'POST',{status:'approved',comment:'Сайн гүйцэтгэл.',competent:true});
  ({notebook:book}=await request('a',`/api/notebooks/${bookId}/submit`,'POST',{}));
  await request('a',`/api/notebooks/${bookId}`,'PATCH',{profile,sections,schedule:book.schedule,revision:book.revision},409);
  await request('a',`/api/notebooks/${bookId}/evaluation`,'PUT',{scores:[20,10,20,10,30,10],grade:'A',teacher:'Багш',conclusion:'Сайн'},403);
  await request('admin',`/api/notebooks/${bookId}/evaluation`,'PUT',{scores:[21,10,20,10,30,10],grade:'A',teacher:'Багш',conclusion:'Сайн'},400);
  await request('admin',`/api/notebooks/${bookId}/evaluation`,'PUT',{scores:[20,10,20,10,30,10],grade:'A',teacher:'Тэрбиш',conclusion:'Маш сайн дадлага хийсэн.'});
  await request('admin',`/api/notebooks/${bookId}/review`,'POST',{status:'approved',comment:'Тайланг батлав.'});
  const final=await request('a',`/api/notebooks/${bookId}`);check(final.notebook.evaluation.scores.reduce((a,b)=>a+b,0)===100,'Evaluation totals 100');check(final.entries[0].competent===true,'Competency assessment persisted');
  const report=await request('a',`/api/notebooks/${bookId}/pdf`);check(report.headers.get('content-type')==='application/pdf','PDF response type');
  const pdfBytes=new Uint8Array(await report.arrayBuffer());const pdf=await PDFDocument.load(pdfBytes);check(pdf.getPageCount()>=12,'Full PDF contains all notebook sections and overflow pages');
  mkdirSync('outputs',{recursive:true});writeFileSync('outputs/test-report.pdf',pdfBytes);
  await request('a','/api/auth/sign-out','POST',{});await request('a','/api/me','GET',undefined,401);
  await request('a','/api/auth/sign-in/email','POST',{email:'a@dadlaga.test',password:'TraineeTest!2026'});
  check((await request('a','/api/notebooks/mine')).notebook.sections.report===sections.report,'Notebook survives logout and re-login');
  const reset=await request('admin',`/api/admin/users/${a.id}/reset-password`,'POST',{});
  await request('a','/api/me','GET',undefined,401);
  await request('a','/api/auth/sign-in/email','POST',{email:'a@dadlaga.test',password:reset.password});
  await request('admin',`/api/admin/users/${a.id}`,'PATCH',{status:'disabled'});
  await request('a','/api/me','GET',undefined,401);
  await request('a','/api/auth/sign-in/email','POST',{email:'a@dadlaga.test',password:reset.password},403);
  console.log(`PASS: ${assertions} integration checks; ${pdf.getPageCount()}-page Mongolian PDF exported.`);
}finally{await mf.dispose();}
