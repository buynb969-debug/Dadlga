import { and, eq, desc, sql, inArray } from 'drizzle-orm';
import { hashPassword } from 'better-auth/crypto';
import { ZodError, z } from 'zod';
import * as s from '../db/schema';
import { auth, bootstrapAdmin, database, env, HttpError, json, protectMutation, requireUser } from './server';
import { initialProfile } from './content';
import { editable, entryInput, evaluationInput, notebookInput, reviewInput, validFile } from './validation';
import type { AppUser, NotebookData } from './types';
import { exportNotebook } from './pdf';

const now = () => new Date().toISOString();
const decodeNotebook = (row: typeof s.notebooks.$inferSelect) => ({ ...row, profile: JSON.parse(row.profile), sections: JSON.parse(row.sections), schedule: JSON.parse(row.schedule), evaluation: JSON.parse(row.evaluation) });
async function body(request: Request) {
  if (!request.headers.get('content-type')?.includes('application/json')) throw new HttpError(415, 'JSON хүсэлт шаардлагатай.');
  const text = await request.text(); if (text.length > 1_000_000) throw new HttpError(413, 'Мэдээллийн хэмжээ хэтэрсэн.');
  try { return JSON.parse(text); } catch { throw new HttpError(400, 'Мэдээллийн формат буруу.'); }
}
async function ownNotebook(id: string, user: AppUser) {
  const book = await database().select().from(s.notebooks).where(eq(s.notebooks.id, id)).get();
  if (!book || (user.role !== 'admin' && book.userId !== user.id)) throw new HttpError(404, 'Дэвтэр олдсонгүй.');
  return book;
}
async function ownEntry(id: string, user: AppUser) {
  const entry = await database().select().from(s.entries).where(eq(s.entries.id, id)).get();
  if (!entry) throw new HttpError(404, 'Тэмдэглэл олдсонгүй.');
  const notebook = await ownNotebook(entry.notebookId, user);
  return { entry, notebook };
}
async function notebookData(id: string, user: AppUser) {
  const book = await ownNotebook(id, user); const db = database();
  const records = await db.select().from(s.entries).where(eq(s.entries.notebookId,id)).orderBy(desc(s.entries.date), desc(s.entries.createdAt));
  const files = records.length ? await db.select({ id:s.attachments.id,entryId:s.attachments.entryId,name:s.attachments.name,type:s.attachments.type,size:s.attachments.size }).from(s.attachments).where(inArray(s.attachments.entryId, records.map(e=>e.id))) : [];
  const owner = await db.select({ id:s.user.id,name:s.user.name,email:s.user.email,role:s.user.role,status:s.user.status }).from(s.user).where(eq(s.user.id,book.userId)).get();
  return { notebook:decodeNotebook(book), entries:records.map(e=>({...e, attachments:files.filter(f=>f.entryId===e.id)})), owner } as NotebookData;
}
const bookUnlocked = (id: string) => sql`exists (select 1 from notebooks where notebooks.id = ${id} and notebooks.status in ('draft','returned'))`;

export async function handleApi(request: Request): Promise<Response> {
  try {
    await bootstrapAdmin();
    const path = new URL(request.url).pathname.slice(5).split('/').filter(Boolean); const method=request.method;
    if (path[0] === 'auth') return await auth(request).handler(request);
    protectMutation(request);
    const user = await requireUser(request); const db=database();
    if (path[0] === 'me' && method==='GET') return json({user});

    if (path[0] === 'notebooks') {
      let id = path[1];
      if (id === 'mine') {
        if (user.role !== 'intern') throw new HttpError(403,'Энэ хэсэг дадлагажигчийн эрхтэй.');
        const stamp=now(); const bookId=crypto.randomUUID();
        await db.insert(s.notebooks).values({ id:bookId, userId:user.id, profile:JSON.stringify({...initialProfile,firstName:user.name}), schedule:JSON.stringify(Array.from({length:27},(_,i)=>({week:i+1,organization:'Номин',plan:''}))), createdAt:stamp,updatedAt:stamp }).onConflictDoNothing();
        id=(await db.select().from(s.notebooks).where(eq(s.notebooks.userId,user.id)).get())!.id;
      }
      if (!id) throw new HttpError(404,'Дэвтэр олдсонгүй.');
      const book=await ownNotebook(id,user);
      if (method==='GET' && !path[2]) return json(await notebookData(id,user));
      if (method==='GET' && path[2]==='pdf') return exportNotebook(await notebookData(id,user),request);
      if (user.role==='admin' && !['review','evaluation'].includes(path[2]||'')) throw new HttpError(403,'Дэвтрийн агуулгыг зөвхөн эзэмшигч засна.');
      if (method==='PATCH' && !path[2]) {
        if (!editable(book.status)) throw new HttpError(409,'Илгээсэн дэвтрийг засварлах боломжгүй.');
        const input=notebookInput.parse(await body(request));
        const {startDate,endDate}=input.profile;
        if (startDate && endDate && endDate < startDate) throw new HttpError(400,'Дуусах огноо эхлэх огнооноос өмнө байна.');
        const result=await db.update(s.notebooks).set({profile:JSON.stringify(input.profile),sections:JSON.stringify(input.sections),schedule:JSON.stringify(input.schedule),revision:book.revision+1,updatedAt:now()}).where(and(eq(s.notebooks.id,id),eq(s.notebooks.revision,input.revision),inArray(s.notebooks.status,['draft','returned']))).returning();
        if (!result.length) throw new HttpError(409,'Өөр цонхноос мэдээлэл өөрчлөгдсөн байна. Хуудсыг шинэчилнэ үү.');
        return json({notebook:decodeNotebook(result[0])});
      }
      if (method==='POST' && path[2]==='safety') {
        if (!editable(book.status)) throw new HttpError(409,'Дэвтэр түгжигдсэн байна.');
        const result=await db.update(s.notebooks).set({safetyAcknowledgedAt:book.safetyAcknowledgedAt||now(),updatedAt:now(),revision:book.revision+1}).where(and(eq(s.notebooks.id,id),eq(s.notebooks.revision,book.revision),inArray(s.notebooks.status,['draft','returned']))).returning();
        if(!result.length) throw new HttpError(409,'Мэдээлэл шинэчлэгдсэн байна. Дахин оролдоно уу.');
        return json({notebook:decodeNotebook(result[0])});
      }
      if (method==='POST' && path[2]==='submit') {
        if (!editable(book.status)) throw new HttpError(409,'Дэвтэр аль хэдийн илгээгдсэн байна.');
        const p=JSON.parse(book.profile), sections=JSON.parse(book.sections);
        if (!p.lastName?.trim() || !p.firstName?.trim() || !p.organization?.trim() || !p.startDate || !p.endDate || !sections.report?.trim()) throw new HttpError(400,'Овог, нэр, байгууллага, дадлагын хугацаа, тайлангаа бүрэн бөглөнө үү.');
        if (!book.safetyAcknowledgedAt) throw new HttpError(400,'ХАБЭА-н заавартай уншиж танилцана уу.');
        const result=await db.update(s.notebooks).set({status:'submitted',comment:'',revision:book.revision+1,updatedAt:now()}).where(and(eq(s.notebooks.id,id),eq(s.notebooks.revision,book.revision),inArray(s.notebooks.status,['draft','returned']),sql`exists (select 1 from entries where notebook_id=${id})`,sql`not exists (select 1 from entries where notebook_id=${id} and status != 'approved')`)).returning();
        if(!result.length) throw new HttpError(409,'Эхлээд бүх өдрийн тэмдэглэлээ батлуулаад тайлангаа илгээнэ үү.');
        return json({notebook:decodeNotebook(result[0])});
      }
      if (method==='POST' && path[2]==='review') {
        if(user.role!=='admin') throw new HttpError(403,'Админ эрх шаардлагатай.');
        const input=reviewInput.parse(await body(request));
        if(book.status!=='submitted' && !(book.status==='approved' && input.status==='returned')) throw new HttpError(409,'Зөвхөн илгээсэн тайланг хянана.');
        const result=await db.update(s.notebooks).set({status:input.status,comment:input.comment,revision:book.revision+1,updatedAt:now()}).where(and(eq(s.notebooks.id,id),eq(s.notebooks.revision,book.revision))).returning();
        if(!result.length) throw new HttpError(409,'Тайлангийн төлөв өөрчлөгдсөн байна.');
        return json({notebook:decodeNotebook(result[0])});
      }
      if (method==='PUT' && path[2]==='evaluation') {
        if(user.role!=='admin') throw new HttpError(403,'Админ эрх шаардлагатай.');
        if(!['submitted','approved'].includes(book.status)) throw new HttpError(409,'Тайлан илгээгдсэний дараа үнэлнэ.');
        const evaluation=evaluationInput.parse(await body(request));
        const result=await db.update(s.notebooks).set({evaluation:JSON.stringify(evaluation),revision:book.revision+1,updatedAt:now()}).where(and(eq(s.notebooks.id,id),eq(s.notebooks.revision,book.revision))).returning();
        if(!result.length) throw new HttpError(409,'Мэдээлэл өөрчлөгдсөн байна.');
        return json({notebook:decodeNotebook(result[0])});
      }
      if (method==='POST' && path[2]==='entries') {
        if(!editable(book.status)) throw new HttpError(409,'Дэвтэр түгжигдсэн байна.');
        const stamp=now(); const entryId=crypto.randomUUID();
        const date=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ulaanbaatar',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
        const inserted=await env.DB.prepare("INSERT INTO entries (id,notebook_id,date,created_at,updated_at) SELECT ?,?,?,?,? WHERE EXISTS (SELECT 1 FROM notebooks WHERE id=? AND status IN ('draft','returned'))").bind(entryId,id,date,stamp,stamp,id).run();
        if(!inserted.meta.changes) throw new HttpError(409,'Дэвтэр түгжигдсэн байна.');
        const created=await db.select().from(s.entries).where(eq(s.entries.id,entryId)).get();
        return json({entry:{...created,attachments:[]}},201);
      }
    }

    if(path[0]==='entries' && path[1]) {
      const {entry,notebook}=await ownEntry(path[1],user);
      if(path[2]==='review' && method==='POST') {
        if(user.role!=='admin') throw new HttpError(403,'Админ эрх шаардлагатай.');
        const input=reviewInput.parse(await body(request));
        if(entry.status!=='submitted' && !(entry.status==='approved' && input.status==='returned' && editable(notebook.status))) throw new HttpError(409,'Энэ тэмдэглэлийн төлөвийг өөрчлөх боломжгүй.');
        const updated=await db.update(s.entries).set({status:input.status,comment:input.comment,competent:input.status==='approved'?(input.competent??true):null,revision:entry.revision+1,updatedAt:now()}).where(and(eq(s.entries.id,entry.id),eq(s.entries.revision,entry.revision))).returning();
        if(!updated.length) throw new HttpError(409,'Тэмдэглэлийн төлөв өөрчлөгдсөн байна.');
        return json({entry:updated[0]});
      }
      if(user.role!=='intern') throw new HttpError(403,'Тэмдэглэлийг зөвхөн эзэмшигч засна.');
      if(!editable(notebook.status)||!editable(entry.status)) throw new HttpError(409,'Илгээсэн тэмдэглэл түгжигдсэн байна.');
      if(method==='PATCH' && !path[2]) {
        const input=entryInput.parse(await body(request)); const {revision,...fields}=input;
        const updated=await db.update(s.entries).set({...fields,revision:revision+1,updatedAt:now()}).where(and(eq(s.entries.id,entry.id),eq(s.entries.revision,revision),inArray(s.entries.status,['draft','returned']),bookUnlocked(notebook.id))).returning();
        if(!updated.length) throw new HttpError(409,'Өөр цонхноос тэмдэглэл өөрчлөгдсөн байна. Хуудсыг шинэчилнэ үү.');
        return json({entry:updated[0]});
      }
      if(method==='POST' && path[2]==='submit') {
        if(!entry.work.trim()||entry.hours<=0||!entry.competency) throw new HttpError(400,'Хийсэн ажил, цаг, чадамжийг бөглөнө үү.');
        const updated=await db.update(s.entries).set({status:'submitted',comment:'',revision:entry.revision+1,updatedAt:now()}).where(and(eq(s.entries.id,entry.id),eq(s.entries.revision,entry.revision),inArray(s.entries.status,['draft','returned']),bookUnlocked(notebook.id))).returning();
        if(!updated.length) throw new HttpError(409,'Тэмдэглэл өөрчлөгдсөн байна.');
        return json({entry:updated[0]});
      }
      if(method==='DELETE' && !path[2]) {
        const files=await db.select().from(s.attachments).where(eq(s.attachments.entryId,entry.id));
        const deleted=await env.DB.batch([
          env.DB.prepare("DELETE FROM attachments WHERE entry_id=? AND EXISTS (SELECT 1 FROM entries e JOIN notebooks n ON e.notebook_id=n.id WHERE e.id=? AND e.revision=? AND e.status IN ('draft','returned') AND n.status IN ('draft','returned'))").bind(entry.id,entry.id,entry.revision),
          env.DB.prepare("DELETE FROM entries WHERE id=? AND revision=? AND status IN ('draft','returned') AND EXISTS (SELECT 1 FROM notebooks WHERE id=? AND status IN ('draft','returned'))").bind(entry.id,entry.revision,notebook.id),
        ]);
        if(!deleted[1].meta.changes) throw new HttpError(409,'Тэмдэглэл шинэчлэгдсэн байна.');
        await Promise.all(files.map(f=>env.BUCKET.delete(f.key)));
        return json({ok:true});
      }
      if(method==='POST' && path[2]==='files') {
        const length=Number(request.headers.get('content-length')||0); if(length>11*1024*1024) throw new HttpError(413,'Файл 10 МБ-аас их байна.');
        let form:FormData;
        try { form=await request.formData(); } catch { throw new HttpError(400,'Файлын хүсэлтийг уншиж чадсангүй. Файлаа дахин сонгоно уу.'); }
        const file=form.get('file');
        if(!file||typeof file==='string'||!file.size||file.size>10*1024*1024) throw new HttpError(400,'10 МБ хүртэл хэмжээтэй файл сонгоно уу.');
        const bytes=new Uint8Array(await file.arrayBuffer());
        if(!validFile(bytes,file.type)) throw new HttpError(400,'PNG, JPEG, WebP зураг эсвэл PDF файл оруулна уу.');
        const id=crypto.randomUUID(), key=`${user.id}/${id}`;
        await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:file.type}});
        try {
          const saved=await env.DB.prepare("INSERT INTO attachments (id,entry_id,user_id,key,name,type,size,created_at) SELECT ?,?,?,?,?,?,?,? WHERE EXISTS (SELECT 1 FROM entries e JOIN notebooks n ON e.notebook_id=n.id WHERE e.id=? AND e.status IN ('draft','returned') AND n.status IN ('draft','returned'))").bind(id,entry.id,user.id,key,file.name.slice(0,200),file.type,file.size,now(),entry.id).run();
          if(!saved.meta.changes) throw new HttpError(409,'Тэмдэглэл илгээгдсэн байна.');
        } catch(error) { await env.BUCKET.delete(key); throw error; }
        return json({file:{id,entryId:entry.id,name:file.name.slice(0,200),type:file.type,size:file.size}},201);
      }
    }

    if(path[0]==='files' && path[1]) {
      const file=await db.select().from(s.attachments).where(eq(s.attachments.id,path[1])).get();
      if(!file) throw new HttpError(404,'Файл олдсонгүй.');
      const {entry,notebook}=await ownEntry(file.entryId,user);
      if(method==='GET') {
        const object=await env.BUCKET.get(file.key); if(!object) throw new HttpError(404,'Файл олдсонгүй.');
        return new Response(object.body,{headers:{'Content-Type':file.type,'Content-Disposition':`attachment; filename*=UTF-8''${encodeURIComponent(file.name)}`,'X-Content-Type-Options':'nosniff','Cache-Control':'private, no-store'}});
      }
      if(method==='DELETE') {
        if(user.role!=='intern'||file.userId!==user.id||!editable(entry.status)||!editable(notebook.status)) throw new HttpError(403,'Файл устгах эрхгүй.');
        const deleted=await env.DB.prepare("DELETE FROM attachments WHERE id=? AND EXISTS (SELECT 1 FROM entries e JOIN notebooks n ON e.notebook_id=n.id WHERE e.id=? AND e.status IN ('draft','returned') AND n.status IN ('draft','returned'))").bind(file.id,entry.id).run();
        if(!deleted.meta.changes) throw new HttpError(409,'Тэмдэглэл илгээгдсэн байна.');
        await env.BUCKET.delete(file.key);
        return json({ok:true});
      }
    }

    if(path[0]==='admin') {
      if(user.role!=='admin') throw new HttpError(403,'Админ эрх шаардлагатай.');
      if(path[1]==='users' && !path[2] && method==='GET') return json({users:await db.select({id:s.user.id,name:s.user.name,email:s.user.email,role:s.user.role,status:s.user.status,createdAt:s.user.createdAt}).from(s.user).orderBy(desc(s.user.createdAt))});
      if(path[1]==='users' && path[2]) {
        const target=await db.select().from(s.user).where(eq(s.user.id,path[2])).get();
        if(!target||target.role==='admin') throw new HttpError(400,'Админы эрхийг энд өөрчлөх боломжгүй.');
        if(method==='PATCH' && !path[3]) {
          const input=z.object({status:z.enum(['active','disabled'])}).parse(await body(request));
          await db.batch([db.update(s.user).set({status:input.status,updatedAt:new Date()}).where(eq(s.user.id,target.id)),db.delete(s.session).where(eq(s.session.userId,target.id))]);
          return json({ok:true});
        }
        if(method==='POST' && path[3]==='reset-password') {
          const password=`D${crypto.randomUUID().replace(/-/g,'').slice(0,14)}!a7`;
          const hash=await hashPassword(password);
          await db.batch([db.update(s.account).set({password:hash,updatedAt:new Date()}).where(and(eq(s.account.userId,target.id),eq(s.account.providerId,'credential'))),db.delete(s.session).where(eq(s.session.userId,target.id))]);
          return json({password});
        }
      }
      if(path[1]==='notebooks' && method==='GET') {
        const rows=await db.select({notebook:s.notebooks,owner:{id:s.user.id,name:s.user.name,email:s.user.email,status:s.user.status}}).from(s.notebooks).innerJoin(s.user,eq(s.notebooks.userId,s.user.id)).orderBy(desc(s.notebooks.updatedAt));
        const counts=await db.select({notebookId:s.entries.notebookId,count:sql<number>`count(*)`,submitted:sql<number>`sum(case when status='submitted' then 1 else 0 end)`,hours:sql<number>`sum(hours)`}).from(s.entries).groupBy(s.entries.notebookId);
        return json({notebooks:rows.map(r=>({...r,notebook:decodeNotebook(r.notebook),stats:counts.find(c=>c.notebookId===r.notebook.id)||{count:0,submitted:0,hours:0}}))});
      }
    }
    throw new HttpError(404,'Хуудас олдсонгүй.');
  } catch(error) {
    if(error instanceof HttpError) return json({error:error.message},error.status);
    if(error instanceof ZodError) return json({error:'Талбаруудын утга буруу эсвэл хязгаараас хэтэрсэн байна.',fields:error.issues.map(i=>i.path.join('.'))},400);
    console.error('Request failed',error instanceof Error?error.name:'unknown');
    return json({error:'Сервер хүсэлтийг гүйцэтгэж чадсангүй. Дахин оролдоно уу.'},500);
  }
}
