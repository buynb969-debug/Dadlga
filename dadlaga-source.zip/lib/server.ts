import { env as bindings } from 'cloudflare:workers';
import { drizzle } from 'drizzle-orm/d1';
import { eq } from 'drizzle-orm';
import { betterAuth } from 'better-auth';
import { APIError } from 'better-auth/api';
import { drizzleAdapter } from 'better-auth/adapters/drizzle';
import * as schema from '../db/schema';
import type { AppUser } from './types';

export interface AppEnv { DB: D1Database; BUCKET: R2Bucket; ASSETS: Fetcher; AUTH_SECRET: string; ADMIN_EMAIL: string; ADMIN_PASSWORD_HASH: string; SITE_URL: string }
export const env = bindings as unknown as AppEnv;
export const database = () => drizzle(env.DB, { schema });
let initialized: Promise<void> | undefined;
export async function bootstrapAdmin() {
  if (!env.AUTH_SECRET || !env.ADMIN_PASSWORD_HASH || !env.ADMIN_EMAIL) throw new HttpError(503, 'Серверийн нэвтрэлтийн тохиргоо бүрэн хийгдээгүй байна.');
  if (!initialized) initialized = (async () => {
    const db = database(); const now = new Date();
    await db.batch([
      db.insert(schema.user).values({ id: 'bootstrap-admin', name: 'Буяндэлгэр', email: env.ADMIN_EMAIL.toLowerCase(), emailVerified: true, role: 'admin', status: 'active', createdAt: now, updatedAt: now }).onConflictDoNothing(),
      db.insert(schema.account).values({ id: 'bootstrap-admin-credential', userId: 'bootstrap-admin', accountId: 'bootstrap-admin', providerId: 'credential', password: env.ADMIN_PASSWORD_HASH, createdAt: now, updatedAt: now }).onConflictDoNothing(),
    ]);
  })().catch(error => { initialized = undefined; throw error; });
  await initialized;
}
export function auth(request: Request) {
  const baseURL = env.SITE_URL || new URL(request.url).origin;
  const db = database();
  return betterAuth({
    baseURL, basePath: '/api/auth', secret: env.AUTH_SECRET,
    database: drizzleAdapter(db, { provider: 'sqlite', schema }),
    trustedOrigins: [baseURL],
    emailAndPassword: { enabled: true, autoSignIn: false, minPasswordLength: 10, maxPasswordLength: 128 },
    user: { additionalFields: {
      role: { type: 'string', defaultValue: 'intern', input: false },
      status: { type: 'string', defaultValue: 'pending', input: false },
    } },
    session: { expiresIn: 60 * 60 * 24 * 7, updateAge: 60 * 60 * 12, cookieCache: { enabled: false } },
    rateLimit: { enabled: true, storage: 'database', window: 60, max: 60, customRules: {
      '/sign-in/email': { window: 60, max: 5 }, '/sign-up/email': { window: 3600, max: 10 },
    } },
    advanced: { cookiePrefix: 'dadlaga', useSecureCookies: baseURL.startsWith('https:'), ipAddress: { ipAddressHeaders: ['cf-connecting-ip'] } },
    databaseHooks: { session: { create: { before: async (value) => {
      const found = await db.select().from(schema.user).where(eq(schema.user.id, value.userId)).get();
      if (!found || found.status !== 'active') throw new APIError('FORBIDDEN', { message: found?.status === 'pending' ? 'Таны бүртгэл админы зөвшөөрөл хүлээж байна.' : 'Таны эрх түдгэлзсэн байна.' });
      return { data: value };
    } } } },
  });
}
export class HttpError extends Error { constructor(public status: number, message: string) { super(message); } }
export async function requireUser(request: Request, admin = false): Promise<AppUser> {
  const result = await auth(request).api.getSession({ headers: request.headers });
  if (!result) throw new HttpError(401, 'Үргэлжлүүлэхийн тулд нэвтэрнэ үү.');
  const found = await database().select().from(schema.user).where(eq(schema.user.id, result.user.id)).get();
  if (!found || found.status !== 'active') throw new HttpError(403, 'Бүртгэл идэвхгүй байна.');
  if (admin && found.role !== 'admin') throw new HttpError(403, 'Админ эрх шаардлагатай.');
  return found as AppUser;
}
export function protectMutation(request: Request) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(request.method)) return;
  const origin = request.headers.get('origin');
  if (!origin || origin !== (env.SITE_URL || new URL(request.url).origin)) throw new HttpError(403, 'Хүсэлтийн эх үүсвэр зөвшөөрөгдөөгүй.');
}
export const json = (data: unknown, status = 200) => Response.json(data, { status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
