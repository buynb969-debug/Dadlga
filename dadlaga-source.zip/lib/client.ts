'use client';
import { useCallback, useEffect, useRef, useState } from 'react';

export async function api<T = any>(path:string, options:RequestInit = {}):Promise<T> {
  const response=await fetch(path,{credentials:'same-origin',...options,headers:{...(options.body && !(options.body instanceof FormData)?{'Content-Type':'application/json'}:{}),...options.headers}});
  const data:any=await response.json().catch(()=>({error:'Хүсэлтийг гүйцэтгэж чадсангүй.'}));
  if(!response.ok) throw new Error(data.error||data.message||'Хүсэлтийг гүйцэтгэж чадсангүй.');
  return data;
}
export const send=(method:string,value?:unknown):RequestInit=>({method,...(value!==undefined?{body:JSON.stringify(value)}:{})});
export const dateText=(date:string)=>new Intl.DateTimeFormat('mn-MN',{timeZone:'Asia/Ulaanbaatar',year:'numeric',month:'short',day:'numeric'}).format(new Date(date.length===10?`${date}T00:00:00+08:00`:date));

// Serializes writes and preserves keystrokes typed while an earlier save is in flight.
export function useDraft<T extends { id:string; revision:number }>(initial:T, enabled:boolean, fields:(value:T)=>unknown, persist:(value:T)=>Promise<Partial<T>>) {
  const [doc,setDocState]=useState(initial);
  const latest=useRef(initial), saved=useRef(JSON.stringify(fields(initial))), pending=useRef<Promise<void>|null>(null);
  const [status,setStatus]=useState<'saved'|'waiting'|'saving'|'error'>('saved');
  const [error,setError]=useState(''); const fieldFn=useRef(fields), persistFn=useRef(persist);
  fieldFn.current=fields;persistFn.current=persist;
  const setDoc=useCallback((update:T|((old:T)=>T))=>{
    const next=typeof update==='function'?(update as (old:T)=>T)(latest.current):update;
    latest.current=next;setDocState(next);
  },[]);
  useEffect(()=>{
    if(!pending.current && saved.current===JSON.stringify(fieldFn.current(latest.current))) {
      latest.current=initial;setDocState(initial);saved.current=JSON.stringify(fieldFn.current(initial));
    }
  },[initial.id,initial.revision]);
  const flush=useCallback(async function flushAll():Promise<void>{
    if(pending.current) { await pending.current; return flushAll(); }
    const snapshot=latest.current; const serial=JSON.stringify(fieldFn.current(snapshot));
    if(serial===saved.current) return;
    setStatus('saving');setError('');
    const task=(async()=>{
      const result=await persistFn.current(snapshot);
      latest.current={...latest.current,...Object.fromEntries(Object.entries(result).filter(([key])=>['revision','updatedAt'].includes(key)))};
      setDocState(latest.current);saved.current=serial;setStatus('saved');
    })();
    pending.current=task;
    try {await task;} catch(e){setStatus('error');setError(e instanceof Error?e.message:'Хадгалахад алдаа гарлаа.');throw e;} finally {pending.current=null;}
    if(saved.current!==JSON.stringify(fieldFn.current(latest.current))) await flushAll();
  },[]);
  const serial=JSON.stringify(fields(doc));
  useEffect(()=>{
    if(!enabled || serial===saved.current) return;
    setStatus('waiting');
    const timer=setTimeout(()=>{void flush().catch(()=>{});},900);
    return ()=>clearTimeout(timer);
  },[serial,enabled,flush]);
  useEffect(()=>{
    const guard=(event:BeforeUnloadEvent)=>{if(saved.current!==JSON.stringify(fieldFn.current(latest.current))){event.preventDefault();event.returnValue='';}};
    window.addEventListener('beforeunload',guard);return()=>window.removeEventListener('beforeunload',guard);
  },[]);
  return {doc,setDoc,flush,status,error,current:()=>latest.current};
}
