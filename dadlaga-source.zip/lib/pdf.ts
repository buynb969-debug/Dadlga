import { PDFDocument, rgb, type PDFPage, type PDFFont } from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';
import { competencies, profileFields, reminders, reportRequirements, safetyRules, scoreCriteria, sectionFields, statusNames } from './content';
import { env, database } from './server';
import { attachments } from '../db/schema';
import { eq } from 'drizzle-orm';
import type { NotebookData } from './types';

export async function exportNotebook(data: NotebookData, request: Request) {
  const pdf = await PDFDocument.create(); pdf.registerFontkit(fontkit);
  const asset = async (name: string) => new Uint8Array(await (await env.ASSETS.fetch(new URL(`/assets/${name}`, request.url))).arrayBuffer());
  const [regularBytes,boldBytes,logoBytes]=await Promise.all([asset('NotoSans-Regular.ttf'),asset('NotoSans-Bold.ttf'),asset('production-logo.png')]);
  const regular=await pdf.embedFont(regularBytes,{subset:true}), bold=await pdf.embedFont(boldBytes,{subset:true});
  const logo=await pdf.embedPng(logoBytes);
  const black=rgb(.09,.10,.12), gray=rgb(.42,.44,.47), red=rgb(.88,.04,.12);
  let page!:PDFPage; let y=0;
  const clean=(value:unknown) => String(value??'').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g,'');
  function newPage() {
    page=pdf.addPage([595.28,841.89]); y=767;
    page.drawImage(logo,{x:48,y:790,width:49,height:21.4});
    page.drawText('ДАДЛАГА / ЦАХИМ ДЭВТЭР',{x:111,y:797,size:8,font:bold,color:gray});
    page.drawLine({start:{x:48,y:782},end:{x:547,y:782},thickness:.7,color:rgb(.88,.88,.88)});
  }
  function lines(text:string,font:PDFFont,size:number,width:number) {
    const out:string[]=[];
    for(const paragraph of clean(text).split('\n')) {
      let line='';
      for(const word of paragraph.split(/\s+/)) {
        if(!word) continue;
        if(font.widthOfTextAtSize(word,size)>width) {
          if(line) {out.push(line);line='';}
          let chunk='';for(const ch of word) {if(font.widthOfTextAtSize(chunk+ch,size)>width){out.push(chunk);chunk=ch;}else chunk+=ch;}line=chunk;
        } else if(line && font.widthOfTextAtSize(`${line} ${word}`,size)>width) {out.push(line);line=word;}
        else line=line?`${line} ${word}`:word;
      }
      out.push(line);
    }
    return out;
  }
  function write(text:unknown,size=10,isBold=false,color=black,indent=0) {
    const font=isBold?bold:regular;
    for(const line of lines(clean(text),font,size,499-indent)) {
      if(y<size*1.6+55) newPage();
      page.drawText(line,{x:48+indent,y,size,font,color}); y-=size*1.55;
    }
    y-=5;
  }
  const heading=(title:string,section?:string)=>{newPage();if(section)write(section,9,true,red);write(title,22,true);y-=12;};
  const {notebook:book,entries,owner}=data; const p=book.profile;
  newPage();
  y=690;write('РАЖИВ ГАНДИЙН НЭРЭМЖИТ',11,true);write('ҮЙЛДВЭРЛЭЛ УРЛАЛЫН ПОЛИТЕХНИК КОЛЛЕЖ',11,true);y-=76;
  write('АЖЛЫН БАЙРАН ДАХ',24,true);write('ДАДЛАГЫН ДЭВТЭР',29,true,red);y-=30;
  write(p.specialty||'Мэдээллийн технологи, техник хангамж',14,true);y-=46;
  write(`Суралцагч: ${p.lastName||'................'} ${p.firstName||owner.name}`,12);
  write(`Анги: ${p.className||'................'}`,12);write(`Байгууллага: ${p.organization||'................'}`,12);
  write(`Хугацаа: ${p.startDate||'................'} — ${p.endDate||'................'}`,12);
  write(`Төлөв: ${statusNames[book.status]}`,10,false,gray);
  y=145;write('2026 ОН',12,true);write('Цахим дэвтрээс үүсгэсэн хувилбар',9,false,gray);
  heading('Оюутны ерөнхий мэдээлэл','01 / ХУВИЙН МЭДЭЭЛЭЛ');
  for(const [key,label] of profileFields) write(`${label}: ${p[key]||'........................................................'}`);
  heading('Санамж ба тайлангийн шаардлага','02 / УДИРДАМЖ');
  reminders.forEach((rule,i)=>write(`${i+1}. ${rule}`));y-=15;write('Тайланд тавигдах шаардлага',15,true);
  reportRequirements.forEach((rule,i)=>write(`${i+1}. ${rule}`));
  heading('Хөдөлмөрийн аюулгүй байдал, эрүүл ахуй','03 / ХАБЭА');
  safetyRules.forEach((rule,i)=>write(`${i+1}. ${rule}`));
  write(`Цахимаар уншиж танилцсан: ${book.safetyAcknowledgedAt?new Date(book.safetyAcknowledgedAt).toLocaleString('mn-MN',{timeZone:'Asia/Ulaanbaatar'}):'Баталгаажуулаагүй'}`,10,true);
  write('Зааварчилгаа өгсөн: ........................................ /........................../');
  write(`Зааварчилгаа авсан: ${p.firstName||owner.name} /........................../`);
  write('Цахимаар уншиж танилцсан тэмдэглэгээг гарын үсэг, тамганы оронд тооцохгүй.',9,false,gray);
  heading('Дадлагын хөтөлбөр','04 / ЧАДАМЖИЙН НЭГЖҮҮД');
  write('Дадлагажих нийт цаг: 1080 цаг',13,true,red);
  for(const unit of competencies) {
    if(y<150)newPage();
    write(`${unit.title} · ${unit.code}`,13,true);write(unit.subtitle,10,false,gray);
    unit.criteria.forEach(([text,hours],i)=>write(`${i+1}. ${text} — ${hours} цаг`,9));
    write(`Ур чадвар: ${unit.skills}`,9,false,gray);y-=14;
  }
  heading('Дадлагын график','05 / 27 ДОЛОО ХОНОГ');
  for(const week of book.schedule) {
    write(`${String(week.week).padStart(2,'0')}-р долоо хоног · ${week.organization||p.organization||'Байгууллага'}`,11,true);
    write(week.plan||'Төлөвлөгөө бөглөөгүй',10,false,week.plan?black:gray);
  }
  heading('Өдрийн тэмдэглэл','06 / ХИЙЖ ГҮЙЦЭТГЭСЭН АЖИЛ');
  if(!entries.length)write('Одоогоор тэмдэглэл оруулаагүй байна.');
  for(const [i,e] of [...entries].reverse().entries()) {
    if(y<150)newPage();
    write(`${i+1}. ${e.date} · ${e.hours} цаг · ${statusNames[e.status]}`,12,true);
    write(competencies.find(c=>c.id===e.competency)?.title||'Чадамж сонгоогүй',10,false,red);
    write(e.work||'Агуулгагүй ноорог');
    write(`Чадамжтай эсэх: ${e.competent===null?'Үнэлээгүй':e.competent?'Тийм':'Үгүй'}`,9);
    if(e.comment)write(`Админы тайлбар: ${e.comment}`,9,false,gray);
    for(const file of e.attachments) {
      write(`Хавсралт: ${file.name}`,9,false,gray);
      if(['image/png','image/jpeg'].includes(file.type)) {
        const record=await database().select().from(attachments).where(eq(attachments.id,file.id)).get();
        const object=record?await env.BUCKET.get(record.key):null;
        if(object) {
          const bytes=await object.arrayBuffer();
          const image=file.type==='image/png'?await pdf.embedPng(bytes):await pdf.embedJpg(bytes);
          const scale=Math.min(499/image.width,285/image.height,1), w=image.width*scale,h=image.height*scale;
          if(y-h<65)newPage();
          page.drawImage(image,{x:48,y:y-h,width:w,height:h});y-=h+16;
        }
      }
    }
    write('Баталгаажуулсан удирдагч: ............................. /........................../',9,false,gray);y-=12;
  }
  for(const [i,field] of sectionFields.filter(f=>f.key!=='certificate').entries()) {
    heading(field.title,`${String(i+7).padStart(2,'0')} / ТАЙЛАН`);write(book.sections[field.key]||'Бөглөөгүй');
  }
  heading('Төгсөлтийн өмнөх дадлагын тодорхойлолт','11 / БАЙГУУЛЛАГЫН ТОДОРХОЙЛОЛТ');
  write(`2026 оны .... сарын .... өдөр                         ${p.city||'................'} хот/аймаг`);y-=14;
  write(`ҮУПК-ийн ${p.specialty||'................................'} мэргэжлийн ${p.className||'........'} ангийн суралцагч ${p.lastName||'................'} овогтой ${p.firstName||owner.name} нь ${p.organization||'................................'} байгууллагад ${p.startDate||'................'}-ээс ${p.endDate||'................'} хүртэл төгсөлтийн өмнөх дадлага хийв.`);
  write('Дадлагын хугацаанд техникийн ур чадварын хувьд ........... үнэлгээтэй дадлагын хөтөлбөрийг биелүүлсэн болохыг тодорхойлов.');
  if(book.sections.certificate)write(book.sections.certificate);
  y-=24;write(`Аж ахуйн нэгжийн нэр: ${p.organization||'................................'}`);
  write(`ААНБ-ыг төлөөлж: ${p.supervisor||'................................'} /........................../`);
  write(`Дадлага удирдсан багш: ${p.teacherName||'................................'} /........................../`);
  y-=24;write('Тамга, тэмдэг:',11,true);y-=80;
  heading('Дадлагын үр дүнгийн үнэлгээ','12 / НИЙТ 100 ОНОО');
  scoreCriteria.forEach((c,i)=>write(`${c.name}: ${book.evaluation.scores?.[i]??'......'} / ${c.max} оноо`,12));
  write(`Нийт: ${book.evaluation.scores?book.evaluation.scores.reduce((a,b)=>a+b,0):'......'} / 100`,17,true,red);
  write(`Үнэлгээ: ${book.evaluation.grade||'................................'}`);
  write(`Дүгнэсэн багш: ${book.evaluation.teacher||'................................'} /........................../`);
  if(book.evaluation.conclusion)write(`Дүгнэлт: ${book.evaluation.conclusion}`);
  if(book.comment)write(`Тайлангийн хяналтын тайлбар: ${book.comment}`);
  for(const [index,pdfPage] of pdf.getPages().entries()) {
    pdfPage.drawLine({start:{x:48,y:43},end:{x:547,y:43},color:rgb(.88,.88,.88),thickness:.5});
    pdfPage.drawText(`${p.firstName||owner.name} · Дадлагын дэвтэр`,{x:48,y:28,size:8,font:regular,color:gray});
    pdfPage.drawText(`${index+1} / ${pdf.getPageCount()}`,{x:510,y:28,size:8,font:regular,color:gray});
  }
  pdf.setTitle('Дадлагын дэвтэр');pdf.setAuthor(p.firstName||owner.name);pdf.setSubject('ҮУПК · Мэдээллийн технологи, техник хангамж');
  const bytes=await pdf.save();
  return new Response(bytes.buffer as ArrayBuffer,{headers:{'Content-Type':'application/pdf','Content-Disposition':`attachment; filename="dadlagyn-devter.pdf"; filename*=UTF-8''${encodeURIComponent(`${p.firstName||owner.name}-дадлагын-дэвтэр.pdf`)}`,'Cache-Control':'private, no-store'}});
}
