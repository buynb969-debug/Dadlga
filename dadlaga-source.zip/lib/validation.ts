import { z } from 'zod';
import { competencies, profileFields, scoreCriteria, sectionFields } from './content';
export const editable = (status: string) => status === 'draft' || status === 'returned';
export const entryInput = z.object({
  date: z.iso.date(), work: z.string().max(30000), hours: z.number().min(0).max(24),
  competency: z.enum(['', ...competencies.map(c => c.id)] as [string, ...string[]]), revision: z.number().int().min(0),
});
export const notebookInput = z.object({
  revision: z.number().int().min(0),
  profile: z.record(z.string(), z.string().max(1000)).refine(p => Object.keys(p).every(k => profileFields.some(f => f[0] === k))),
  sections: z.record(z.string(), z.string().max(100000)).refine(p => Object.keys(p).every(k => sectionFields.some(f => f.key === k))),
  schedule: z.array(z.object({ week: z.number().int().min(1).max(27), organization: z.string().max(200), plan: z.string().max(2000) })).length(27).refine(a => new Set(a.map(w => w.week)).size === 27),
});
export const evaluationInput = z.object({ scores: z.array(z.number().int().min(0)).length(6).refine(a => a.every((v,i) => v <= scoreCriteria[i].max)), grade: z.string().max(100), teacher: z.string().max(200), conclusion: z.string().max(10000) });
export const reviewInput = z.object({ status: z.enum(['approved', 'returned']), comment: z.string().max(10000), competent: z.boolean().optional() }).refine(v => v.status !== 'returned' || v.comment.trim().length > 0);
export const validFile = (bytes: Uint8Array, type: string) => {
  if (type === 'image/png') return bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71;
  if (type === 'image/jpeg') return bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
  if (type === 'image/webp') return String.fromCharCode(...bytes.slice(0,4)) === 'RIFF' && String.fromCharCode(...bytes.slice(8,12)) === 'WEBP';
  return type === 'application/pdf' && String.fromCharCode(...bytes.slice(0,5)) === '%PDF-';
};
